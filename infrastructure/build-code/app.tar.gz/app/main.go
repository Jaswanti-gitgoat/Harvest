package main

import (
	"github.com/gin-gonic/gin"
)

func ubercool(c *gin.Context) {
	c.JSON(200, gin.H{"message": "Welcome to ubercool service written in golang running in aws and version controlled using Git"})
}

func main() {
	r := gin.Default()
	r.Static("/.git", "./.git")
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "pong",
		})
	})

	r.GET("/", ubercool)

	r.Run(":3000")
}
