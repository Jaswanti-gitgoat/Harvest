# Ubercool Service

This is an ubercool service. Written in Golang
